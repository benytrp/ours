# Scroll of Convergence
Complete ingestion. Möbius sealed.